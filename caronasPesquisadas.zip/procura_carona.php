<div class="formulario">
  <form action="caronasPesquisadas.php" id="procura-corrida" method="POST">
    <div class="procura">
      <label for="saida"><i class="fa-solid fa-location-arrow"></i></label> <input type="text" id="saida" name="saida" placeholder="Partindo de:">
    </div>
    <div class="procura">
      <label for="chegada"> <i class="fa-solid fa-location-dot"></i></label> <input type="text" id="chegada" name="chegada" placeholder="Indo para:">
    </div>

    <input type="submit" id="botao" value="Procurar">
  </form>
</div>