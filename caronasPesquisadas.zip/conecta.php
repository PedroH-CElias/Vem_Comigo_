<?php

function abreConexao() {
    $servername = "http://vem-comigo.freeoda.com/pma/.";
    $database = "397097";
    $username = "397097";
    $password = "Brdeal1234";
    
    $conn = mysqli_connect($servername, $username, $password, $database);
    // Check connection
    if (!$conn) {
        die("Falha na conexão: " . mysqli_connect_error());
    } 
    return $conn;
}
?>