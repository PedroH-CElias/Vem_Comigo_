<footer>
    <a href="#" class="back-to-top"></a>
    <div class="footer">
        <img id="imgfooter" src="img/pneu-footer.png" alt="LogoFooter">
        <div class="texto">
            <p>&copy; Copyright - Todos os direitos reservados - 2022<br>Passos-MG</p>
        </div>
        <div class="links">
            <a href="https://github.com/DioneJA" target="_blank"><img src="img/github.png" alt=""></a>
            <a href="https://www.instagram.com/pedrohrsilva66/?hl=pt-br" target="_blank"><img src="img/instagram.png" alt=""></a>
            <a href="https://www.linkedin.com/in/pedro-henrique-9b7955208/" target="_blank"><img src="img/linkedin.png" alt=""></a>
        </div>
    </div>

</footer>